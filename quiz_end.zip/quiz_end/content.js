// Prevent duplicate initialization
if (window.quizAutoSolverLoaded) {
  console.log('Quiz Auto-Solver already loaded');
} else {
  window.quizAutoSolverLoaded = true;

class QuizAutoSolver {
  constructor() {
    this.isRunning = false;
    this.stats = { total: 0, high: 0, medium: 0, low: 0 };
    this.lastQuestion = '';
    this.config = {};
    this.knowledgeBase = {
      aws: ['s3', 'ec2', 'lambda', 'dynamodb', 'rds', 'vpc', 'iam', 'cloudformation'],
      devops: ['docker', 'kubernetes', 'jenkins', 'git', 'ci/cd', 'terraform'],
      cloud: ['scalability', 'availability', 'elasticity', 'fault tolerance']
    };
  }

  async init() {
    await this.loadConfig();
    this.setupMessageListener();
    console.log('Quiz Auto-Solver initialized');
  }

  async loadConfig() {
    this.config = {
      email: 'Mgr yum nantha',
      password: 'Sivaji yum nantha'
    };
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      switch(request.action) {
        case 'toggle':
          if (this.isRunning) {
            this.stop();
            console.log('Auto-solver stopped');
          } else {
            this.start().then(() => console.log('Auto-solver started'));
          }
          sendResponse({success: true});
          break;
        case 'start':
          this.start().then(() => sendResponse({success: true}));
          break;
        case 'stop':
          this.stop();
          sendResponse({success: true});
          break;
      }
      return true;
    });
  }

  async start() {
    if (this.isRunning) return;
    
    await this.loadConfig();

    this.isRunning = true;
    console.log('Starting auto-solver...');
    
    // Try auto-login first
    await this.autoLogin();
    
    // Start main loop
    this.mainLoop();
  }

  stop() {
    this.isRunning = false;
    console.log('Auto-solver stopped');
  }

  async autoLogin() {
    console.log('Starting auto-login...');
    
    // Wait for page to load
    await this.sleep(2000);
    
    try {
      // Find email field with more selectors
      const emailSelectors = [
        "input[type='email']",
        "input[name*='email' i]",
        "input[id*='email' i]",
        "input[placeholder*='email' i]",
        "input[name*='user' i]",
        "input[id*='user' i]",
        "input[class*='email' i]"
      ];
      
      let emailField = null;
      for (const selector of emailSelectors) {
        const fields = document.querySelectorAll(selector);
        for (const field of fields) {
          if (field.offsetParent !== null) {
            emailField = field;
            break;
          }
        }
        if (emailField) break;
      }

      if (emailField) {
        console.log('Found email field');
        emailField.focus();
        emailField.value = '';
        emailField.value = this.config.email;
        emailField.dispatchEvent(new Event('input', { bubbles: true }));
        emailField.dispatchEvent(new Event('change', { bubbles: true }));
        
        await this.sleep(1000);
        
        // Try to find and click next/continue button
        if (this.clickNextButton()) {
          console.log('Clicked next after email');
          await this.sleep(3000);
        }
        
        // Look for password field
        const passwordSelectors = [
          "input[type='password']",
          "input[name*='password' i]",
          "input[id*='password' i]",
          "input[placeholder*='password' i]"
        ];
        
        let passwordField = null;
        for (const selector of passwordSelectors) {
          const fields = document.querySelectorAll(selector);
          for (const field of fields) {
            if (field.offsetParent !== null) {
              passwordField = field;
              break;
            }
          }
          if (passwordField) break;
        }
        
        if (passwordField) {
          console.log('Found password field');
          passwordField.focus();
          passwordField.value = '';
          passwordField.value = this.config.password;
          passwordField.dispatchEvent(new Event('input', { bubbles: true }));
          passwordField.dispatchEvent(new Event('change', { bubbles: true }));
          
          await this.sleep(1000);
          
          if (this.clickLoginButton()) {
            console.log('Clicked login button');
            await this.sleep(3000);
          }
        } else {
          console.log('Password field not found');
        }
      } else {
        console.log('Email field not found');
      }
    } catch (error) {
      console.error('Auto-login failed:', error);
    }
  }

  async mainLoop() {
    while (this.isRunning) {
      try {
        const question = this.findQuestion();
        if (!question || question === this.lastQuestion) {
          await this.sleep(1000);
          continue;
        }

        this.lastQuestion = question;
        console.log('Found question:', question.substring(0, 80) + '...');

        const options = this.findOptions();
        if (!options.length) {
          await this.sleep(1000);
          continue;
        }

        const answer = await this.getAIAnswer(question, options);
        if (answer) {
          const success = await this.selectBestOption(answer, options);
          if (success) {
            this.stats.total++;
            await this.sleep(500);
            this.clickNextButton();
            await this.sleep(1500);
          }
        }
      } catch (error) {
        console.error('Main loop error:', error.message || error);
        await this.sleep(2000);
      }
    }
  }

  findQuestion() {
    const selectors = [
      ".question-text",
      ".question", 
      "p",
      "div",
      "h1", "h2", "h3",
      "*[class*='question']",
      "span",
      "label"
    ];

    for (const selector of selectors) {
      try {
        const elements = document.querySelectorAll(selector);
        for (const elem of elements) {
          if (!elem.offsetParent) continue;
          const text = elem.textContent.trim();
          if (text.length > 15 && (text.includes('?') || 
              /\b(what|which|how|why|when|where|select|choose|identify)\b/i.test(text))) {
            return text;
          }
        }
      } catch (e) {
        continue;
      }
    }
    return null;
  }

  findOptions() {
    const selectors = [
      "input[type='radio']",
      "input[type='checkbox']",
      "label",
      ".option",
      "li.option",
      "button.option",
      "div[onclick]",
      "span[onclick]"
    ];

    for (const selector of selectors) {
      try {
        const options = Array.from(document.querySelectorAll(selector))
          .filter(opt => opt.offsetParent);
        if (options.length >= 2) return options;
      } catch (e) {
        continue;
      }
    }
    return [];
  }

  getOptionText(opt) {
    if (opt.textContent && opt.textContent.trim()) {
      return opt.textContent.trim();
    }
    
    if (opt.tagName === 'INPUT') {
      const label = document.querySelector(`label[for='${opt.id}']`) ||
                   opt.closest('label') ||
                   opt.nextElementSibling;
      if (label && label.textContent) {
        return label.textContent.trim();
      }
    }
    
    return opt.value || '';
  }

  async getAIAnswer(question, options) {
    try {
      const optionsText = options.map((opt, i) => 
        `${String.fromCharCode(65 + i)}. ${this.getOptionText(opt)}`
      ).join('\n');

      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          action: 'makeGroqRequest',
          data: {
            question: question,
            options: optionsText
          }
        }, response => {
          if (response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response.error));
          }
        });
      });

      return response;
    } catch (error) {
      console.error('AI request failed:', error);
      return null;
    }
  }

  async selectBestOption(answer, options) {
    const answerNorm = this.normalize(answer);
    let bestOption = null;
    let bestRatio = 0;
    let confidenceLevel = 'low';

    for (const opt of options) {
      const optText = this.getOptionText(opt);
      if (!optText) continue;

      const optNorm = this.normalize(optText);
      const ratio = this.calculateSimilarity(answerNorm, optNorm);

      if (ratio > bestRatio) {
        bestRatio = ratio;
        bestOption = opt;
      }
    }

    if (bestRatio > 0.4) {
      confidenceLevel = 'high';
      this.stats.high++;
    } else if (bestRatio > 0.2) {
      confidenceLevel = 'medium';
      this.stats.medium++;
    } else {
      confidenceLevel = 'low';
      this.stats.low++;
    }

    if (bestOption) {
      this.safeClick(bestOption);
      console.log(`Selected option with ${confidenceLevel} confidence (${bestRatio.toFixed(2)})`);
      return true;
    }

    return false;
  }

  normalize(text) {
    if (!text) return '';
    return text.toLowerCase()
      .replace(/[^\w\s\-\.]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  calculateSimilarity(str1, str2) {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.length === 0) return 1.0;
    
    const editDistance = this.levenshteinDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    return matrix[str2.length][str1.length];
  }

  safeClick(element) {
    try {
      element.scrollIntoView({ block: 'center' });
      
      // Try different click methods
      if (element.tagName === 'INPUT') {
        element.checked = true;
        element.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        element.click();
      }
      
      // Also try clicking associated radio button
      const radio = element.querySelector('input[type="radio"]') ||
                   element.closest('label')?.querySelector('input[type="radio"]');
      if (radio) {
        radio.checked = true;
        radio.dispatchEvent(new Event('change', { bubbles: true }));
      }
      
      return true;
    } catch (error) {
      console.error('Click failed:', error);
      return false;
    }
  }

  clickNextButton() {
    const nextSelectors = [
      "button",
      "input[type='submit']",
      "input[type='button']",
      "a",
      "div[role='button']",
      "span[role='button']"
    ];

    for (const selector of nextSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const elem of elements) {
        if (elem.offsetParent !== null) {
          const text = (elem.textContent || elem.value || '').toLowerCase();
          if (text.includes('next') || text.includes('continue') || text.includes('proceed') || text.includes('→') || text.includes('>')) {
            elem.scrollIntoView({ block: 'center' });
            elem.click();
            return true;
          }
        }
      }
    }
    return false;
  }

  clickLoginButton() {
    const loginSelectors = [
      "button",
      "input[type='submit']",
      "input[type='button']",
      "a",
      "div[role='button']"
    ];

    for (const selector of loginSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const elem of elements) {
        if (elem.offsetParent !== null) {
          const text = (elem.textContent || elem.value || '').toLowerCase();
          if (text.includes('login') || text.includes('sign in') || text.includes('submit') || text.includes('enter')) {
            elem.scrollIntoView({ block: 'center' });
            elem.click();
            return true;
          }
        }
      }
    }
    return false;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Initialize the auto-solver with error handling
let autoSolver;
try {
  autoSolver = new QuizAutoSolver();
  autoSolver.init();
  window.autoSolver = autoSolver;
  console.log('Quiz Auto-Solver content script loaded');
} catch (error) {
  console.error('Failed to initialize auto-solver:', error);
}

} // End of duplicate prevention check