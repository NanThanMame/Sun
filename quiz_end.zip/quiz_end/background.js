chrome.runtime.onInstalled.addListener(() => {
  console.log('Quiz Auto-Solver extension installed');
});

// Handle extension icon click
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url.includes('placement.skcet.ac.in')) {
    try {
      // Inject content script if not already injected
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      
      // Wait a bit for script to initialize
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, {action: 'toggle'}, (response) => {
          if (chrome.runtime.lastError) {
            console.log('Content script not ready, injecting...');
          }
        });
      }, 500);
    } catch (error) {
      console.error('Failed to inject script:', error);
    }
  } else {
    chrome.tabs.create({url: 'https://placement.skcet.ac.in/'});
  }
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'makeGroqRequest') {
    makeGroqRequest(request.data)
      .then(response => sendResponse({success: true, data: response}))
      .catch(error => {
        console.error('Groq API error:', error);
        sendResponse({success: false, error: error.message});
      });
    return true;
  }
});

async function makeGroqRequest(requestData) {
  const { question, options } = requestData;
  const apiKey = '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';
  
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama-3.3-70b-versatile',
      messages: [
        {
          role: 'system',
          content: 'You are an expert in cloud computing, AWS, DevOps, databases, and technology. Answer multiple choice questions with precision.'
        },
        {
          role: 'user',
          content: `Question: ${question}\n\nOptions:\n${options}\n\nAnalyze the question carefully and provide ONLY the exact letter and text of the correct answer (e.g., 'A. Amazon S3').`
        }
      ],
      max_tokens: 150,
      temperature: 0.1
    })
  });

  if (!response.ok) {
    throw new Error(`Groq API error: ${response.status}`);
  }

  const data = await response.json();
  return data.choices[0].message.content.trim();
}